from pymongo import MongoClient
import requests
from termcolor import colored
from Link_finder import link_finder
from ytDownloader import ytDownloader
from Editor import editor
from Uploader import uploader


try:
    client = MongoClient('localhost', 27017)
    db = client['Gigmire-Test']
    scraped = db['Scraped-simulate']
    daily = db['Daily']
    print(colored('Connection to database successful...', 'green'))
except:
    print(colored('Couldn\'t connect to the database...', 'red'))

real_link = False
while real_link == False:
    link = link_finder(scraped, daily)
    downloader_output = ytDownloader(link)
    cdn = downloader_output['link']
    vidTitle = downloader_output['title']

    if vidTitle.find('Family') or vidTitle.find('family') != 1:
        real_link = True
    else:
        real_link = False

# Downloading
r = requests.get(cdn, allow_redirects=True)
open('.\TheGreatAutomation\TheGreatAutomation\RawVid.mp4', 'wb').write(r.content)

# Editing
editor('.\TheGreatAutomation\TheGreatAutomation\RawVid.mp4')

# Creating Title
raw_title = vidTitle
final_title = f'{raw_title} | #Shorts #FamilyGuy #PeterGriffin #Quagmire'

# Final-Upload
vID = uploader.main(final_title, '.\TheGreatAutomation\TheGreatAutomation\\final.mp4', 'unlisted')









